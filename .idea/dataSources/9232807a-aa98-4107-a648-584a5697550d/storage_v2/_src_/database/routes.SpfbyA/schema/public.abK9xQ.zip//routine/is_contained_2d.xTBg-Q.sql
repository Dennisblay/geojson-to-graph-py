create function is_contained_2d(geometry, box2df) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$SELECT $2 OPERATOR(public.~) $1;$$;

alter function is_contained_2d(geometry, box2df) owner to postgres;

