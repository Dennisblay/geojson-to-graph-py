create function st_linesubstring(text, double precision, double precision) returns geometry
    immutable
    parallel safe
    language sql
as
$$ SELECT public.ST_LineSubstring($1::public.geometry, $2, $3);  $$;

alter function st_linesubstring(text, double precision, double precision) owner to postgres;

